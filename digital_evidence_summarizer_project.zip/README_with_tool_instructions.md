# 🧠 Digital Evidence Summarizer (GPT-4)

Created by **Jerson Recarte** for **Prof. Douglas**  
John Jay College – Digital Forensics and Cybersecurity

---

## 📝 Overview

This tool uses **OpenAI's GPT-4** model to help forensic investigators summarize digital evidence extracted from different tools. It provides a Gradio-powered web interface where the user can:

- Paste raw digital evidence or metadata
- Upload `.txt` or `.csv` files
- Choose the analysis mode (General, FTK Imager, or Autopsy)
- Receive a clear, GPT-generated forensic summary

---

## 🧰 What This Tool Supports

### 🔍 1. **General Mode**
- For pasted notes, file metadata, or any evidence
- Outputs a standard summary suitable for reports

### 🧪 2. **FTK Imager Mode**
- FTK Imager is used to create forensic disk images and view their content (e.g., carved files, timestamps, hashes).
- Upload FTK Imager export files (e.g., file listings in `.csv` or `.txt` format)
- The model identifies artifacts, suspicious patterns, and user activity

### 📂 3. **Autopsy Mode**
- Autopsy is a digital forensics platform used for timeline creation, keyword searching, and file analysis
- Upload timeline reports or keyword hit exports
- The model generates a narrative timeline and highlights key actions or anomalies

---

## 🖥️ What Is Gradio?

**Gradio** provides a lightweight web interface for Python scripts. In this project, it’s used to let the user interact with the evidence processor directly in the browser—no coding required.

---

## 🚀 Setup Instructions

### 1. Clone the Repository

```bash
git clone https://github.com/YOUR_USERNAME/digital-evidence-summarizer.git
cd digital-evidence-summarizer
```

### 2. Install Required Libraries

```bash
pip install openai gradio python-dotenv
```

### 3. Create a `.env` File

In the project root, create a file named `.env` and paste this line:

```
OPENAI_API_KEY=sk-your-api-key-here
```

### 4. Run the Application

```bash
python digital_evidence_summarizer.py
```

---

## 📂 File Upload Examples

### FTK Imager File Sample:
```
Filename: evidence_1.jpg
Path: /Recovered/Deleted/
SHA256: abc123...
Created: 2023-02-14 10:34:21
Modified: 2023-02-15 09:31:12
Comment: Found during volume shadow copy analysis
```

### Autopsy Timeline Sample:
```
Event: File Accessed
Timestamp: 2023-04-01 11:12:03
User: jsmith
Path: C:/Users/jsmith/Documents/report.docx
```

---

## ✅ Output Example

GPT-4 will return:
```
User jsmith accessed 'report.docx' on April 1, 2023. The file was located in the user's documents folder, suggesting intentional use. Timestamps align with peak login hours.
```

---

## 👨‍🏫 Instructor Notes for Prof. Douglas

- This project is designed to showcase the integration of generative AI in digital forensics
- Each analysis mode adapts GPT-4 prompts based on tool output type
- It serves as both a teaching aid and a prototype for automated forensic report assistance

---

*Made with ❤️ by Jerson Recarte*
